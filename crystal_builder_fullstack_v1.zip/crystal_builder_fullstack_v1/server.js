
const http = require('http');
const fs = require('fs');
const fsp = require('fs/promises');
const path = require('path');
const crypto = require('crypto');
const { URL } = require('url');

const ROOT = __dirname;
const PUBLIC_DIR = path.join(ROOT, 'public');
const DATA_DIR = path.join(ROOT, 'data');
const CATALOG_FILE = path.join(DATA_DIR, 'catalog.json');
const DESIGNS_FILE = path.join(DATA_DIR, 'designs.json');
const PORT = process.env.PORT || 3000;

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.webp': 'image/webp'
};

function sendJson(res, statusCode, data) {
  const body = JSON.stringify(data, null, 2);
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(body);
}

function sendText(res, statusCode, text) {
  res.writeHead(statusCode, {
    'Content-Type': 'text/plain; charset=utf-8',
    'Cache-Control': 'no-store'
  });
  res.end(text);
}

async function readJson(filePath, fallback) {
  try {
    const text = await fsp.readFile(filePath, 'utf-8');
    return JSON.parse(text);
  } catch (error) {
    if (error.code === 'ENOENT' && fallback !== undefined) return fallback;
    throw error;
  }
}

async function writeJson(filePath, data) {
  await fsp.writeFile(filePath, JSON.stringify(data, null, 2), 'utf-8');
}

function formatIntentLabel(intent) {
  return intent.charAt(0).toUpperCase() + intent.slice(1).replace(/-/g, ' ');
}

function getTopLabels(countMap, max = 2) {
  return Object.entries(countMap)
    .sort((a, b) => b[1] - a[1])
    .slice(0, max)
    .map(([label]) => formatIntentLabel(label));
}

async function getCatalog() {
  return readJson(CATALOG_FILE, {});
}

async function getDesigns() {
  return readJson(DESIGNS_FILE, []);
}

function getSizeById(catalog, sizeId) {
  return catalog.sizes.find((size) => size.id === sizeId) || catalog.sizes[0];
}

function getBeadById(catalog, beadId) {
  return catalog.beads.find((bead) => bead.id === beadId);
}

function buildQuote(catalog, payload) {
  const size = getSizeById(catalog, payload.sizeId);
  const basePriceCents = Number(catalog.basePriceCents || 0);
  const items = Array.isArray(payload.items) ? payload.items : [];
  const beadTotals = [];
  let beadsTotalCents = 0;
  const intentionMap = {};
  const zodiacMap = {};
  const materialMap = new Map();

  for (const item of items) {
    const bead = getBeadById(catalog, item.beadId);
    if (!bead) continue;
    beadsTotalCents += bead.priceCents;
    beadTotals.push(bead.priceCents);

    for (const intention of bead.intentions || []) {
      intentionMap[intention] = (intentionMap[intention] || 0) + 1;
    }
    for (const zodiac of bead.zodiacs || []) {
      zodiacMap[zodiac] = (zodiacMap[zodiac] || 0) + 1;
    }

    const existing = materialMap.get(bead.id) || { name: bead.name, qty: 0, totalCents: 0 };
    existing.qty += 1;
    existing.totalCents += bead.priceCents;
    materialMap.set(bead.id, existing);
  }

  const topIntentions = getTopLabels(intentionMap, 2);
  const topZodiac = Object.entries(zodiacMap).sort((a, b) => b[1] - a[1])[0]?.[0];
  const centerLabel = topIntentions.length ? topIntentions.join(' + ') : 'Custom Build';

  const totalCents = basePriceCents + Number(size.surchargeCents || 0) + beadsTotalCents;
  const meaningParts = [];
  if (topIntentions.length) {
    meaningParts.push(`Built around ${topIntentions.join(' and ').toLowerCase()} energy`);
  }
  if (topZodiac) {
    meaningParts.push(`with a strong pull toward ${topZodiac}`);
  }
  if (items.length) {
    meaningParts.push(`using ${items.length} hand-picked beads`);
  }
  const meaningSummary = meaningParts.length
    ? `${meaningParts.join(', ')}. This version stays symbolic and gift-friendly while keeping the builder light and responsive.`
    : 'Start adding beads and the back end will generate the live symbolic summary for this bracelet.';

  return {
    size,
    count: items.length,
    totalCents,
    centerLabel,
    meaningSummary,
    materialBreakdown: Array.from(materialMap.values()).sort((a, b) => b.totalCents - a.totalCents)
  };
}

function normalizePayload(payload) {
  return {
    sizeId: String(payload?.sizeId || 'm'),
    items: Array.isArray(payload?.items)
      ? payload.items
          .filter((item) => item && typeof item.beadId === 'string')
          .map((item) => ({
            key: typeof item.key === 'string' ? item.key : `instance_${crypto.randomBytes(4).toString('hex')}`,
            beadId: item.beadId
          }))
      : []
  };
}

async function parseRequestBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', (chunk) => {
      raw += chunk;
      if (raw.length > 1_000_000) {
        reject(new Error('Request body too large.'));
        req.destroy();
      }
    });
    req.on('end', () => {
      if (!raw) return resolve({});
      try {
        resolve(JSON.parse(raw));
      } catch (error) {
        reject(new Error('Invalid JSON body.'));
      }
    });
    req.on('error', reject);
  });
}

async function saveDesign(payload) {
  const catalog = await getCatalog();
  const normalized = normalizePayload(payload);
  const quote = buildQuote(catalog, normalized);
  const designs = await getDesigns();

  const design = {
    id: `d_${Date.now().toString(36)}_${crypto.randomBytes(3).toString('hex')}`,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    sizeId: normalized.sizeId,
    items: normalized.items,
    quote
  };

  designs.unshift(design);
  await writeJson(DESIGNS_FILE, designs);
  return design;
}

async function findDesign(designId) {
  const designs = await getDesigns();
  return designs.find((design) => design.id === designId);
}

async function serveStatic(req, res, pathname) {
  const safePath = pathname === '/' ? '/index.html' : pathname;
  const filePath = path.join(PUBLIC_DIR, path.normalize(safePath).replace(/^(\.\.[\/\\])+/, ''));
  if (!filePath.startsWith(PUBLIC_DIR)) {
    return sendText(res, 403, 'Forbidden');
  }

  try {
    const stat = await fsp.stat(filePath);
    if (stat.isDirectory()) {
      return serveStatic(req, res, path.join(safePath, 'index.html'));
    }
    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';
    res.writeHead(200, { 'Content-Type': contentType, 'Cache-Control': 'no-store' });
    fs.createReadStream(filePath).pipe(res);
  } catch (error) {
    if (error.code === 'ENOENT') {
      sendText(res, 404, 'Not found');
    } else {
      sendText(res, 500, 'Static file error');
    }
  }
}

const server = http.createServer(async (req, res) => {
  try {
    const parsedUrl = new URL(req.url, `http://${req.headers.host}`);
    const pathname = parsedUrl.pathname;

    if (pathname === '/api/catalog' && req.method === 'GET') {
      const catalog = await getCatalog();
      return sendJson(res, 200, catalog);
    }

    if (pathname === '/api/quote' && req.method === 'POST') {
      const catalog = await getCatalog();
      const payload = normalizePayload(await parseRequestBody(req));
      const quote = buildQuote(catalog, payload);
      return sendJson(res, 200, quote);
    }

    if (pathname === '/api/designs' && req.method === 'POST') {
      const payload = await parseRequestBody(req);
      const design = await saveDesign(payload);
      return sendJson(res, 201, { ok: true, design });
    }

    if (pathname.startsWith('/api/designs/') && req.method === 'GET') {
      const designId = decodeURIComponent(pathname.split('/').pop());
      const design = await findDesign(designId);
      if (!design) return sendJson(res, 404, { error: 'Design not found.' });
      return sendJson(res, 200, { ok: true, design });
    }

    return serveStatic(req, res, pathname);
  } catch (error) {
    console.error(error);
    sendJson(res, 500, { error: error.message || 'Server error.' });
  }
});

server.listen(PORT, () => {
  console.log(`Crystal Builder Full Stack V1 is running at http://localhost:${PORT}`);
});
