
(() => {
  const refs = {
    previewRing: document.getElementById('previewRing'),
    beadPalette: document.getElementById('beadPalette'),
    sizeRow: document.getElementById('sizeRow'),
    selectedHint: document.getElementById('selectedHint'),
    sizeValue: document.getElementById('sizeValue'),
    sizeSub: document.getElementById('sizeSub'),
    countValue: document.getElementById('countValue'),
    priceValue: document.getElementById('priceValue'),
    priceSub: document.getElementById('priceSub'),
    meaningText: document.getElementById('meaningText'),
    meaningPanelText: document.getElementById('meaningPanelText'),
    centerLabel: document.getElementById('centerLabel'),
    saveButton: document.getElementById('saveButton'),
    reviewButton: document.getElementById('reviewButton'),
    ctaButton: document.getElementById('ctaButton'),
    deleteZone: document.getElementById('deleteZone'),
    toast: document.getElementById('toast'),
    tabs: document.getElementById('tabs'),
    designStatusText: document.getElementById('designStatusText'),
    summarySheet: document.getElementById('summarySheet'),
    summaryBackdrop: document.getElementById('summaryBackdrop'),
    summaryClose: document.getElementById('summaryClose'),
    summaryDesignId: document.getElementById('summaryDesignId'),
    summaryMeaning: document.getElementById('summaryMeaning'),
    summaryMaterials: document.getElementById('summaryMaterials'),
    summarySize: document.getElementById('summarySize'),
    summaryPrice: document.getElementById('summaryPrice'),
    serverBadge: document.getElementById('serverBadge')
  };

  const state = {
    catalog: null,
    items: [],
    selectedIndex: null,
    currentSizeId: 'm',
    quote: null,
    savedDesignId: null,
    loadedFromServer: false,
    pressKey: null,
    pointerStart: null,
    longPressTimer: null,
    draggingKey: null,
    currentDragData: null,
    currentGhostEl: null,
    toastTimer: null
  };

  function makeInstance(beadId) {
    return {
      key: `instance_${Math.random().toString(36).slice(2, 10)}`,
      beadId
    };
  }

  function getBead(beadId) {
    return state.catalog.beads.find((bead) => bead.id === beadId);
  }

  function getSize(sizeId) {
    return state.catalog.sizes.find((size) => size.id === sizeId) || state.catalog.sizes[0];
  }

  function formatMoney(cents) {
    return new Intl.NumberFormat('en-US', { style: 'currency', currency: state.catalog?.currency || 'USD' }).format((cents || 0) / 100);
  }

  function showToast(message) {
    clearTimeout(state.toastTimer);
    refs.toast.textContent = message;
    refs.toast.classList.add('is-visible');
    state.toastTimer = setTimeout(() => refs.toast.classList.remove('is-visible'), 2000);
  }

  function bump(el) {
    el.classList.remove('bump');
    void el.offsetWidth;
    el.classList.add('bump');
    setTimeout(() => el.classList.remove('bump'), 240);
  }

  function buildPayload() {
    return {
      sizeId: state.currentSizeId,
      items: state.items.map((item) => ({ key: item.key, beadId: item.beadId }))
    };
  }

  async function api(path, options = {}) {
    const response = await fetch(path, {
      headers: { 'Content-Type': 'application/json' },
      ...options
    });
    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(errorText || `Request failed: ${response.status}`);
    }
    const contentType = response.headers.get('content-type') || '';
    return contentType.includes('application/json') ? response.json() : response.text();
  }

  async function loadCatalog() {
    const data = await api('/api/catalog');
    state.catalog = data;
  }

  function beadPosition(index, total) {
    const size = refs.previewRing.getBoundingClientRect().width || 300;
    const center = size / 2;
    const radius = Math.max(96, size * 0.38);
    const angleStart = -90;
    const angleStep = 360 / Math.max(total, 1);
    const angle = ((angleStart + angleStep * index) * Math.PI) / 180;
    return { x: center + radius * Math.cos(angle), y: center + radius * Math.sin(angle) };
  }

  function updateSelectedHint() {
    refs.selectedHint.classList.toggle('is-hidden', state.selectedIndex === null);
  }

  function renderRing({ popKey = null } = {}) {
    refs.previewRing.querySelectorAll('.ring-bead').forEach((el) => el.remove());
    const total = state.items.length;
    state.items.forEach((item, index) => {
      const bead = getBead(item.beadId);
      const pos = beadPosition(index, total);
      const el = document.createElement('button');
      el.type = 'button';
      el.className = 'ring-bead';
      el.dataset.key = item.key;
      el.style.left = `${pos.x}px`;
      el.style.top = `${pos.y}px`;
      el.style.background = bead.gradient;
      if (state.selectedIndex === index) el.classList.add('is-selected');
      if (state.draggingKey === item.key) el.classList.add('is-ghosted');
      if (popKey && popKey === item.key) el.classList.add('is-pop');
      el.setAttribute('aria-label', bead.name);
      attachBeadEvents(el);
      refs.previewRing.appendChild(el);
    });
    updateSelectedHint();
  }

  function createPalette() {
    refs.beadPalette.innerHTML = '';
    state.catalog.beads.forEach((bead) => {
      const card = document.createElement('button');
      card.type = 'button';
      card.className = 'bead-card';
      card.innerHTML = `
        <div class="bead-card__swatch" style="background:${bead.gradient}"></div>
        <div class="bead-card__name">${bead.name}</div>
        <div class="bead-card__meta">${bead.shortMeta}</div>
        <div class="bead-card__price">${formatMoney(bead.priceCents)}</div>
      `;
      card.addEventListener('click', () => handlePaletteSelect(bead, card));
      refs.beadPalette.appendChild(card);
    });
  }

  function createSizes() {
    refs.sizeRow.innerHTML = '';
    state.catalog.sizes.forEach((size) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `size-pill ${size.id === state.currentSizeId ? 'is-active' : ''}`;
      btn.dataset.sizeId = size.id;
      btn.textContent = size.label;
      btn.addEventListener('click', async () => {
        state.currentSizeId = size.id;
        refs.sizeRow.querySelectorAll('.size-pill').forEach((pill) => pill.classList.toggle('is-active', pill === btn));
        await refreshQuote(true);
      });
      refs.sizeRow.appendChild(btn);
    });
  }

  async function refreshQuote(bumpValues = false) {
    if (!state.catalog) return;
    const quote = await api('/api/quote', { method: 'POST', body: JSON.stringify(buildPayload()) });
    state.quote = quote;
    const currentSize = getSize(state.currentSizeId);
    refs.sizeValue.textContent = currentSize.label;
    refs.sizeSub.textContent = currentSize.fit;
    refs.countValue.textContent = String(state.items.length);
    refs.priceValue.textContent = formatMoney(quote.totalCents);
    refs.priceSub.textContent = 'Server quote';
    refs.centerLabel.textContent = quote.centerLabel;
    refs.meaningText.textContent = quote.meaningSummary;
    refs.meaningPanelText.innerHTML = `<strong>Live meaning:</strong> ${quote.meaningSummary}`;
    refs.ctaButton.textContent = state.savedDesignId ? `Saved · ${formatMoney(quote.totalCents)}` : `Save Design · ${formatMoney(quote.totalCents)}`;
    refs.summaryMeaning.textContent = quote.meaningSummary;
    refs.summarySize.textContent = `${currentSize.label} · ${currentSize.fit}`;
    refs.summaryPrice.textContent = formatMoney(quote.totalCents);
    renderSummaryMaterials(quote.materialBreakdown || []);
    if (bumpValues) {
      bump(refs.countValue);
      bump(refs.priceValue);
    }
    renderDesignStatus();
  }

  function renderSummaryMaterials(items) {
    refs.summaryMaterials.innerHTML = '';
    if (!items.length) {
      refs.summaryMaterials.innerHTML = '<div class="summary-list__item">No materials yet.</div>';
      return;
    }
    items.forEach((item) => {
      const row = document.createElement('div');
      row.className = 'summary-list__item';
      row.innerHTML = `<span><strong>${item.name}</strong> × ${item.qty}</span><span>${formatMoney(item.totalCents)}</span>`;
      refs.summaryMaterials.appendChild(row);
    });
  }

  function renderDesignStatus() {
    if (state.savedDesignId && state.loadedFromServer) {
      refs.designStatusText.textContent = `Loaded from server. Current design ID: ${state.savedDesignId}. The page state came back from the back end and can be shared with ?design=${state.savedDesignId}.`;
    } else if (state.savedDesignId) {
      refs.designStatusText.textContent = `Saved to server. Current design ID: ${state.savedDesignId}. You can reload it later with ?design=${state.savedDesignId}.`;
    } else {
      refs.designStatusText.textContent = 'Not saved yet. The builder is live, and the quote is linked, but this specific design only exists in the current browser until you press Save.';
    }
  }

  function createFloatingGhost({ x, y, gradient }) {
    const ghost = document.createElement('div');
    ghost.className = 'floating-ghost';
    ghost.style.background = gradient;
    ghost.style.left = `${x}px`;
    ghost.style.top = `${y}px`;
    document.body.appendChild(ghost);
    return ghost;
  }

  function animateGhost(ghost, from, to, onDone) {
    ghost.style.left = `${from.x}px`;
    ghost.style.top = `${from.y}px`;
    ghost.animate([
      { left: `${from.x}px`, top: `${from.y}px`, transform: 'translate(-50%, -50%) scale(1)', opacity: 1 },
      { left: `${to.x}px`, top: `${to.y}px`, transform: 'translate(-50%, -50%) scale(.76)', opacity: .94 }
    ], {
      duration: 280,
      easing: 'cubic-bezier(.18,.72,.18,1)',
      fill: 'forwards'
    }).onfinish = () => {
      ghost.remove();
      if (typeof onDone === 'function') onDone();
    };
  }

  function getRingCenterForIndex(index, total) {
    const pos = beadPosition(index, total);
    const rect = refs.previewRing.getBoundingClientRect();
    return { x: rect.left + pos.x, y: rect.top + pos.y };
  }

  async function handlePaletteSelect(bead, card) {
    const swatch = card.querySelector('.bead-card__swatch').getBoundingClientRect();
    const from = { x: swatch.left + swatch.width / 2, y: swatch.top + swatch.height / 2 };

    if (state.selectedIndex !== null) {
      const replaceIndex = state.selectedIndex;
      const targetItem = state.items[replaceIndex];
      const target = getRingCenterForIndex(replaceIndex, Math.max(state.items.length, 1));
      const ghost = createFloatingGhost({ x: from.x, y: from.y, gradient: bead.gradient });
      animateGhost(ghost, from, target, async () => {
        state.items[replaceIndex] = { ...targetItem, beadId: bead.id };
        const popKey = state.items[replaceIndex].key;
        state.selectedIndex = null;
        renderRing({ popKey });
        await refreshQuote(true);
        showToast(`${bead.name} replaced the selected bead.`);
      });
      return;
    }

    const newItem = makeInstance(bead.id);
    state.items.push(newItem);
    const target = getRingCenterForIndex(state.items.length - 1, state.items.length);
    renderRing();
    const newEl = refs.previewRing.querySelector(`[data-key="${newItem.key}"]`);
    if (newEl) {
      newEl.style.opacity = '0';
      newEl.style.transform = 'translate(-50%, -50%) scale(.4)';
    }
    const ghost = createFloatingGhost({ x: from.x, y: from.y, gradient: bead.gradient });
    animateGhost(ghost, from, target, async () => {
      if (newEl) {
        newEl.style.opacity = '';
        newEl.style.transform = '';
      }
      renderRing({ popKey: newItem.key });
      await refreshQuote(true);
      showToast(`${bead.name} added to the bracelet.`);
    });
  }

  function attachBeadEvents(el) {
    el.addEventListener('pointerdown', onBeadPointerDown);
    el.addEventListener('pointermove', onBeadPointerMove);
    el.addEventListener('pointerup', onBeadPointerUp);
    el.addEventListener('pointercancel', onBeadPointerCancel);
  }

  function onBeadPointerDown(event) {
    const key = event.currentTarget.dataset.key;
    try { event.currentTarget.setPointerCapture(event.pointerId); } catch (error) {}
    state.pressKey = key;
    state.pointerStart = { x: event.clientX, y: event.clientY };
    state.longPressTimer = setTimeout(() => startDragging(key, event), 260);
  }

  function onBeadPointerMove(event) {
    if (state.draggingKey) {
      moveDragging(event.clientX, event.clientY);
      return;
    }
    if (!state.pointerStart) return;
    const dx = event.clientX - state.pointerStart.x;
    const dy = event.clientY - state.pointerStart.y;
    if (Math.hypot(dx, dy) > 8) clearLongPress();
  }

  async function onBeadPointerUp(event) {
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch (error) {}
    if (state.draggingKey) {
      await finishDragging(event.clientX, event.clientY);
      return;
    }
    const key = event.currentTarget.dataset.key;
    const index = state.items.findIndex((item) => item.key === key);
    if (index > -1) {
      clearLongPress();
      state.selectedIndex = state.selectedIndex === index ? null : index;
      renderRing();
      const bead = getBead(state.items[index].beadId);
      showToast(state.selectedIndex === null ? 'Selection cleared.' : `${bead.name} selected. Tap another bead below to replace it.`);
    }
  }

  function onBeadPointerCancel(event) {
    try { event.currentTarget.releasePointerCapture(event.pointerId); } catch (error) {}
    if (state.draggingKey) {
      cancelDragging();
      return;
    }
    clearLongPress();
  }

  function clearLongPress() {
    clearTimeout(state.longPressTimer);
    state.longPressTimer = null;
    state.pointerStart = null;
    state.pressKey = null;
  }

  function startDragging(key, event) {
    const index = state.items.findIndex((item) => item.key === key);
    if (index === -1) return;
    clearLongPress();
    const item = state.items[index];
    const bead = getBead(item.beadId);
    state.draggingKey = key;
    state.selectedIndex = null;
    renderRing();
    refs.deleteZone.classList.add('is-visible');
    refs.deleteZone.classList.remove('is-active');
    state.currentDragData = { key, index, beadId: bead.id };
    state.currentGhostEl = createFloatingGhost({ x: event.clientX, y: event.clientY, gradient: bead.gradient });
  }

  function moveDragging(x, y) {
    if (!state.currentGhostEl) return;
    state.currentGhostEl.style.left = `${x}px`;
    state.currentGhostEl.style.top = `${y}px`;
    const overDelete = pointInsideElement(x, y, refs.deleteZone);
    refs.deleteZone.classList.toggle('is-active', overDelete);
  }

  async function finishDragging(x, y) {
    const canDelete = pointInsideElement(x, y, refs.deleteZone);
    if (canDelete && state.currentDragData) {
      const removeIndex = state.items.findIndex((item) => item.key === state.currentDragData.key);
      if (removeIndex > -1) {
        const removed = getBead(state.items[removeIndex].beadId);
        state.items.splice(removeIndex, 1);
        renderRing();
        await refreshQuote(true);
        showToast(`${removed.name} removed.`);
      }
    }
    cleanupDragging();
  }

  function cancelDragging() {
    cleanupDragging();
  }

  function cleanupDragging() {
    if (state.currentGhostEl) state.currentGhostEl.remove();
    state.currentGhostEl = null;
    state.currentDragData = null;
    state.draggingKey = null;
    refs.deleteZone.classList.remove('is-active');
    refs.deleteZone.classList.remove('is-visible');
    renderRing();
  }

  function pointInsideElement(x, y, el) {
    const rect = el.getBoundingClientRect();
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  }

  async function saveCurrentDesign() {
    const response = await api('/api/designs', {
      method: 'POST',
      body: JSON.stringify(buildPayload())
    });
    state.savedDesignId = response.design.id;
    state.loadedFromServer = false;
    await refreshQuote();
    const newUrl = `${window.location.pathname}?design=${state.savedDesignId}`;
    window.history.replaceState({}, '', newUrl);
    refs.summaryDesignId.textContent = state.savedDesignId;
    showToast(`Saved. Design ID: ${state.savedDesignId}`);
  }

  function openSummary() {
    if (!state.quote) return;
    refs.summaryDesignId.textContent = state.savedDesignId || 'Not saved yet';
    refs.summaryMeaning.textContent = state.quote.meaningSummary;
    refs.summarySheet.classList.remove('hidden');
    refs.summarySheet.setAttribute('aria-hidden', 'false');
  }

  function closeSummary() {
    refs.summarySheet.classList.add('hidden');
    refs.summarySheet.setAttribute('aria-hidden', 'true');
  }

  async function maybeLoadDesignFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const designId = params.get('design');
    if (!designId) return false;
    const response = await api(`/api/designs/${encodeURIComponent(designId)}`);
    const design = response.design;
    state.currentSizeId = design.sizeId;
    state.items = design.items.map((item) => ({ key: item.key || makeInstance(item.beadId).key, beadId: item.beadId }));
    state.savedDesignId = design.id;
    state.loadedFromServer = true;
    return true;
  }

  function seedDefaultItems() {
    state.items = state.catalog.beads.slice(0, 8).map((bead) => makeInstance(bead.id));
  }

  function bindActions() {
    refs.saveButton.addEventListener('click', async () => {
      try {
        await saveCurrentDesign();
      } catch (error) {
        showToast(`Save failed: ${error.message}`);
      }
    });

    refs.ctaButton.addEventListener('click', async () => {
      try {
        await saveCurrentDesign();
      } catch (error) {
        showToast(`Save failed: ${error.message}`);
      }
    });

    refs.reviewButton.addEventListener('click', openSummary);
    refs.summaryBackdrop.addEventListener('click', closeSummary);
    refs.summaryClose.addEventListener('click', closeSummary);

    refs.tabs.addEventListener('click', (event) => {
      const btn = event.target.closest('.tab');
      if (!btn) return;
      [...refs.tabs.querySelectorAll('.tab')].forEach((tab) => tab.classList.toggle('is-active', tab === btn));
      document.querySelectorAll('.sheet-panel').forEach((panel) => {
        panel.hidden = panel.dataset.panel !== btn.dataset.tab;
      });
    });

    window.addEventListener('resize', () => renderRing());
  }

  async function init() {
    try {
      await loadCatalog();
      const loaded = await maybeLoadDesignFromUrl();
      if (!loaded) seedDefaultItems();
      createPalette();
      createSizes();
      renderRing();
      await refreshQuote();
      bindActions();
      refs.serverBadge.textContent = loaded ? 'Loaded' : 'API linked';
      refs.summaryDesignId.textContent = state.savedDesignId || 'Not saved yet';
    } catch (error) {
      refs.serverBadge.textContent = 'API error';
      refs.meaningText.textContent = `Start failed: ${error.message}`;
      showToast(`Start failed: ${error.message}`);
      console.error(error);
    }
  }

  init();
})();
